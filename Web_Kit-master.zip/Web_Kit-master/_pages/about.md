---
layout: single
title: "Welcome to My Page"
permalink: /
comments: true
author_profile: true
toc: true
toc_label: "Table of Contents"
toc_sticky: false
---

This repo contains files to my projects and course work. 

### Contact

Mail: email@umich.edu

Tel: (734) 555-5555

### About me
I am a First-Year Masters Student at the University of Michigan
studying Quantitative Finance and Risk Management. 

Here is a link to my [Resume/CV](https://www.google.com).

