---
layout: single
title: "Python Code"
permalink: /python/
comments: true
author_profile: true
toc: true
---

This page contains files to my projects and course work from STATS 506 (Fall 2018)

### Projects and Coursework
- [Monte Carlo Tutorial](https://www.google.com)
- [Health Care Procedure Trends (HCPCS)](https://www.google.com)
